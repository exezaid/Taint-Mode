module Main where

kk = undefined

f x = kk

main = f 3

f ~(Left x) = 3

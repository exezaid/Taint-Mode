
module Priv where

data Privilege l = PR l
